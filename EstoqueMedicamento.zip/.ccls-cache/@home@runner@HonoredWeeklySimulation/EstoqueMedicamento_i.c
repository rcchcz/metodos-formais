/* WARNING if type checker is not performed, translation could contain errors ! */

#include "EstoqueMedicamento.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

#define EstoqueMedicamento__limit 500
#define EstoqueMedicamento__empty 100
/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

static int32_t EstoqueMedicamento__medicamento_nome[EstoqueMedicamento__limit+1];
static int32_t EstoqueMedicamento__medicamento_lote[EstoqueMedicamento__limit+1];
static int32_t EstoqueMedicamento__medicamento_validade[EstoqueMedicamento__limit+1];
static int32_t EstoqueMedicamento__estoque_i[EstoqueMedicamento__limit+1];
static int32_t EstoqueMedicamento__dia_i;
static int32_t EstoqueMedicamento__wm;
/* Clause INITIALISATION */
void EstoqueMedicamento__INITIALISATION(void)
{
    
    unsigned int i = 0;
    for(i = 0; i <= EstoqueMedicamento__limit;i++)
    {
        EstoqueMedicamento__medicamento_nome[i] = 100;
    }
    for(i = 0; i <= EstoqueMedicamento__limit;i++)
    {
        EstoqueMedicamento__medicamento_lote[i] = 0;
    }
    for(i = 0; i <= EstoqueMedicamento__limit;i++)
    {
        EstoqueMedicamento__medicamento_validade[i] = 0;
    }
    EstoqueMedicamento__dia_i = 0;
    for(i = 0; i <= EstoqueMedicamento__limit;i++)
    {
        EstoqueMedicamento__estoque_i[i] = 0;
    }
    EstoqueMedicamento__wm = 0;
}

/* Clause OPERATIONS */

void EstoqueMedicamento__adicionar_medicamento(int32_t ID, EstoqueMedicamento__NOME nome, int32_t lote, int32_t validade)
{
    {
        int32_t yy;
        
        yy = EstoqueMedicamento__limit;
        if(((EstoqueMedicamento__wm) < (yy)))
        {
            EstoqueMedicamento__medicamento_nome[EstoqueMedicamento__wm] = nome;
            EstoqueMedicamento__medicamento_lote[EstoqueMedicamento__wm] = lote;
            EstoqueMedicamento__medicamento_validade[EstoqueMedicamento__wm] = validade;
            EstoqueMedicamento__estoque_i[EstoqueMedicamento__wm] = 0;
            EstoqueMedicamento__wm = EstoqueMedicamento__wm+1;
        }
    }
}

void EstoqueMedicamento__remover_medicamento(int32_t ID)
{
    {
        int32_t mm;
        
        mm = ID+1;
        while((mm) < (EstoqueMedicamento__wm))
        {
            EstoqueMedicamento__medicamento_nome[mm-1] = EstoqueMedicamento__medicamento_nome[mm];
            EstoqueMedicamento__medicamento_lote[mm-1] = EstoqueMedicamento__medicamento_lote[mm];
            EstoqueMedicamento__medicamento_validade[mm-1] = EstoqueMedicamento__medicamento_validade[mm];
            mm = mm+1;
        }
        EstoqueMedicamento__wm = EstoqueMedicamento__wm-1;
    }
}

void EstoqueMedicamento__adicionar_estoque(int32_t ID, int32_t qtd)
{
    EstoqueMedicamento__estoque_i[ID] = EstoqueMedicamento__estoque_i[ID]+qtd;
}

void EstoqueMedicamento__remover_estoque(int32_t ID, int32_t qtd)
{
    EstoqueMedicamento__estoque_i[ID] = EstoqueMedicamento__estoque_i[ID]-qtd;
}

void EstoqueMedicamento__incrementar_dia(void)
{
    EstoqueMedicamento__dia_i = EstoqueMedicamento__dia_i+1;
}

void EstoqueMedicamento__consultar_dia(int32_t *hoje)
{
    (*hoje) = EstoqueMedicamento__dia_i;
}

