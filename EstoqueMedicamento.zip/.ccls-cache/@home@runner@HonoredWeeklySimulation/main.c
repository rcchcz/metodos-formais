#include "EstoqueMedicamento.h"
#include <stdio.h>

int main() {
  int opcao;
  int32_t dia = 0;
  int id = 0;

  do {
    // Exibir conjunto de opções
    printf("\nEscolha uma opção:\n");
    printf("1. Adicionar Medicamento\n");
    printf("2. Remover Medicamento\n");
    printf("3. Incrementar Dia\n");
    printf("4. Consultar Dia\n");
    printf("5. Adicionar Estoque\n");
    printf("6. Remover Estoque\n");
    printf("0. Sair\n");
    printf("Opção: ");
    scanf("%d", &opcao);

    // Chamar método correspondente à opção selecionada
    switch (opcao) {
    case 1:
      printf("Digite o Nome do Medicamento: ");
      int nome;
      int lote;
      int validade;
      scanf("%d", &nome);
      printf("Digite o Lote do Medicamento: ");
      scanf("%d", &lote);
      printf("Digite a Validade do Medicamento: ");
      scanf("%d", &validade);
      EstoqueMedicamento__adicionar_medicamento(id, nome, lote, validade);
      printf("\nMedicamento Inserido Com Sucesso\n");
      id++;
      break;
    case 4:
      EstoqueMedicamento__consultar_dia(&dia);
      printf("\nHoje e: %d", dia);
      break;
    case 3:
      EstoqueMedicamento__incrementar_dia();
      printf("\nDia Incrementado Com Sucesso\n");
      break;
    case 0:
      printf("\nEncerrando o programa. Até logo!\n");
      break;
    case 2:
      printf("\nQual o id do Medicamento? ");
      int32_t idMed;
      scanf("%d", &idMed);
      EstoqueMedicamento__remover_medicamento(idMed);
      printf("\nMedicamento Removido Com Sucesso\n");
      break;
    case 5:
      printf("Qual o id do Medicamento? ");
      int32_t idMedAdd;
      scanf("%d", &idMedAdd);
      printf("Qual a Quantidade que Deseja Adicionar? ");
      int32_t qtd;
      scanf("%d", &qtd);
      EstoqueMedicamento__adicionar_estoque(idMedAdd, qtd);
      printf("\nEstoque Adicionado Com Sucesso\n");
      break;
    case 6:
      printf("Qual o id do Medicamento? ");
      int32_t idMedRet;
      scanf("%d", &idMedRet);
      printf("Qual a Quantidade que Deseja Retirar do Estoque? ");
      int32_t qtdRet;
      scanf("%d", &qtdRet);
      EstoqueMedicamento__remover_estoque(idMedRet, qtdRet);
      printf("\nEstoque Retirado Com Sucesso\n");
      break;
    default:
      printf("\nOpção inválida! Tente novamente.\n");
    }
  } while (opcao != 0);

  return 0;
}