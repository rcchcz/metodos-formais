#ifndef _EstoqueMedicamento_h
#define _EstoqueMedicamento_h

#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define EstoqueMedicamento__NOME__max 299
/* Clause SETS */
typedef int EstoqueMedicamento__NOME;

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
#define EstoqueMedicamento__limit 500
#define EstoqueMedicamento__empty 100
/* Array and record constants */



/* Clause CONCRETE_VARIABLES */

extern void EstoqueMedicamento__INITIALISATION(void);

/* Clause OPERATIONS */

extern void EstoqueMedicamento__adicionar_medicamento(int32_t ID, EstoqueMedicamento__NOME nome, int32_t lote, int32_t validade);
extern void EstoqueMedicamento__remover_medicamento(int32_t ID);
extern void EstoqueMedicamento__adicionar_estoque(int32_t ID, int32_t qtd);
extern void EstoqueMedicamento__remover_estoque(int32_t ID, int32_t qtd);
extern void EstoqueMedicamento__incrementar_dia(void);
extern void EstoqueMedicamento__consultar_dia(int32_t *hoje);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _EstoqueMedicamento_h */
